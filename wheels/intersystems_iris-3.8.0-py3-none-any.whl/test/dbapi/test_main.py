from decimal import Decimal
import copy
import uuid
import datetime
import pytest
import intersystems_iris.dbapi._DBAPI as dbapi
from intersystems_iris.dbapi.preparser._PreParser import StatementType
from intersystems_iris.dbapi._ResultSetRow import from_timestamp_posix


@pytest.fixture(scope="class")
def connection(request):
    if request.config.getoption("--embedded"):
        config = {"embedded": True}
    else:
        config = {
            "hostname": request.config.getoption("--iris-host"),
            "port": request.config.getoption("--iris-port", 1972),
            "namespace": request.config.getoption("--iris-namespace"),
            "username": request.config.getoption("--iris-username"),
            "password": request.config.getoption("--iris-password"),
        }
    with dbapi.connect(**config) as conn:
        if "embedded" in config:
            conn.iris.system.SQL.Purge()
        yield conn


class TestMain:
    cleanup = []

    @pytest.fixture
    def cursor(self, connection):
        with connection.cursor() as cursor:
            yield cursor

    def create(self, cursor, type, name, body):
        try:
            cursor.execute(f"DROP {type} IF EXISTS {name}")
            assert cursor.sqlcode == 100
        except:
            pass
        cursor.execute(f"CREATE {type} {name} {body}")
        assert cursor.sqlcode == 0
        yield name
        cursor.execute(f"DROP {type} {name}")
        assert cursor.sqlcode == 0

    @pytest.fixture
    def proc_test(self, cursor):
        yield from self.create(
            cursor,
            "PROCEDURE",
            "test",
            """(val VARCHAR(10), fail BIT)
RETURNS VARCHAR(10)
LANGUAGE PYTHON
{
    if fail:
        raise Exception('error')
    return ":" + val
}
""",
        )

    @pytest.fixture
    def table_test(self, cursor):
        yield from self.create(
            cursor,
            "TABLE",
            "test",
            "(id IDENTITY PRIMARY KEY, val VARCHAR(''), valtext text, floatval FLOAT, numval NUMERIC(18, 14)) WITH %CLASSPARAMETER ALLOWIDENTITYINSERT = 1",
        )

    @pytest.fixture
    def table_test_streams(self, cursor):
        yield from self.create(
            cursor,
            "TABLE",
            "test",
            "(charstream LONGVARCHAR, binarystream LONGVARBINARY, extra integer)",
        )

    @classmethod
    def teardown_class(self):
        pass

    def test_null(self, cursor: dbapi.Cursor):
        _ = cursor.execute("select Null")
        rows = cursor.fetchall()
        assert rows == [(None,)]

    def test_simple(self, cursor: dbapi.Cursor):
        _ = cursor.execute("select ?", [1])
        rows = cursor.fetchall()
        assert rows == [(1,)]

    def test_longstring(self, cursor: dbapi.Cursor, table_test):
        val = "a" * 100000
        cursor.executemany("INSERT INTO test (val) VALUES (?)", [[val], [val]])

        cursor.execute("SELECT id, val FROM test")
        rows = cursor.fetchall()
        assert [(1, val), (2, val)] == rows

    def test_literals(self, cursor: dbapi.Cursor):
        some_date = datetime.date(2012, 2, 3)
        some_datetime = datetime.datetime(2012, 2, 3, 10, 11, 12, 123)
        some_time = datetime.time(10, 11, 12, 123)
        some_decimal = Decimal("1.234")

        params = [
            2,
            some_date,
            some_datetime,
            some_time,
            some_decimal,
            None,
            "",
            True,
            False,
        ]
        _ = cursor.execute("select 'text', 1, " + ", ".join(["?"] * len(params)), params)
        rows = cursor.fetchall()
        assert rows == [
            (
                "text",
                1,
                2,
                "2012-02-03",
                "2012-02-03 10:11:12.000123",
                "10:11:12.000123",
                Decimal("1.234"),
                None,
                "",
                1,
                0,
            )
        ]

    def test_with(self, cursor):
        cursor.execute("with t1 as (select 1), t2 as (select 2) select * from t1 union all select * from t2")
        rows = cursor.fetchall()
        assert rows == [(1,), (2,)]

    def test_lateral(self, cursor):
        cursor.execute("select * from (select ?) t1,  (select ?) t2", [1, 2])
        rows = cursor.fetchall()
        assert rows == [(1, 2)]

    def test_select_proc(self, cursor, proc_test):  # noqa
        cursor.execute("select test('test1', 0)")
        row = cursor.fetchone()
        assert row == (":test1",)

        with pytest.raises(dbapi.DatabaseError):
            cursor.execute("select test('test1', 1)")

        cursor.execute("select test('test2', 0)")
        row = cursor.fetchone()
        assert row == (":test2",)

        with pytest.raises(dbapi.DatabaseError):
            cursor.execute("select test(?, ?)", ["test1", 1])

    def test_call(self, cursor, proc_test):  # noqa
        cursor.execute("CALL test('test1', 0)")
        with pytest.raises(dbapi.DatabaseError):
            cursor.execute("CALL test('test2', 1)")

        cursor.execute("CALL test(?, ?)", ["test1", False])
        with pytest.raises(dbapi.DatabaseError):
            cursor.execute("CALL test(?, ?)", ["test2", True])

    def test_insert(self, cursor, table_test):
        cursor.execute("INSERT INTO test (id) VALUES (2)")
        assert cursor.rowcount == 1
        assert cursor.lastrowid == 2

        cursor.execute("INSERT INTO test (id) DEFAULT VALUES")
        assert cursor.rowcount == 1
        assert cursor.lastrowid == 3

        cursor.executemany("INSERT INTO test (id) VALUES (?)", [(5,), (7,), (9,)])
        assert cursor.rowcount == 3
        assert cursor.lastrowid == 9

        cursor.execute("INSERT INTO test (id, val) VALUES (10, 1), (11, 2), (12, 3)")
        assert cursor.rowcount == 3
        assert cursor.lastrowid == 12

        cursor.execute("INSERT INTO test (id) VALUES (?), (?), (?)", [15, 16, 17])
        assert cursor.rowcount == 3
        assert cursor.lastrowid == 17

        cursor.execute("SELECT id FROM test")
        rows = cursor.fetchall()
        values = [v for row in rows for v in row]
        assert values == [2, 3, 5, 7, 9, 10, 11, 12, 15, 16, 17]

    def test_insert_literal(self, cursor, table_test):
        cursor.execute("INSERT INTO test (val) VALUES ('test1'), ('test2')")
        assert cursor.rowcount == 2

        cursor.execute("INSERT INTO test (val) VALUES ('test3')")
        assert cursor.rowcount == 1

        cursor.execute("SELECT val FROM test")
        rows = cursor.fetchall()
        values = [v for row in rows for v in row]
        assert values == ['test1', 'test2', 'test3']

        cursor.execute("INSERT INTO test (valtext) VALUES ('test1'), ('test2')")
        assert cursor.rowcount == 2

        cursor.execute("INSERT INTO test (valtext) VALUES ('test3')")
        assert cursor.rowcount == 1

        cursor.execute("SELECT valtext FROM test where valtext is not null")
        rows = cursor.fetchall()
        values = [v for row in rows for v in row]
        assert values == ['test1', 'test2', 'test3']

    def test_insert_float(self, cursor, table_test):
        for _ in range(2):
            cursor.execute("INSERT INTO test set floatval = 15.7563")
            cursor.execute("INSERT INTO test (floatval) VALUES (15.7563)")
            cursor.execute("INSERT INTO test (floatval) VALUES (15.7563),(15.7563)")
            cursor.execute("INSERT INTO test (floatval) VALUES (?)", (15.7563,))
        cursor.execute("SELECT floatval FROM test WHERE floatval is not null")
        rows = cursor.fetchall()
        values = [v for row in rows for v in row]
        assert values == [15.7563] * 10

    def test_insert_numeric(self, cursor, table_test):
        numbers = [
            Decimal("1E-2"),
            Decimal("1E-3"),
            Decimal("1E-4"),
            Decimal("1E-5"),
            Decimal("1E-6"),
            Decimal("1E-7"),
            Decimal("1E-8"),
            Decimal("0.01000005940696"),
            Decimal("0.00000005940696"),
            Decimal("0.00000000000696"),
            Decimal("0.70000000000696"),
            Decimal("696E-12"),
        ]

        cursor.executemany(
            "INSERT INTO test (numval) VALUES (?)",
            [
                [
                    num,
                ]
                for num in numbers
            ],
        )

        cursor.execute("SELECT numval FROM test WHERE numval is not null")
        rows = cursor.fetchall()
        values = [v for row in rows for v in row]
        assert values == numbers

    def test_streams(self, cursor, table_test_streams):
        big_text = "Ф" * 2 * 1024 * 1024
        big_blob = b"\x01" * 4 * 1024 * 1024
        data = [
            (123, "plain text", None),
            (124, None, b"binary data"),
            [125, "Caché", bytes("Caché", "utf-8")],
            [126, big_text, big_blob],
        ]
        orig_data = copy.deepcopy(data)
        cursor.executemany("INSERT INTO test (extra, charstream, binarystream) VALUES (?, ?, ?)", data)
        for row in data:
            cursor.execute("INSERT INTO test (extra, charstream, binarystream) VALUES (?, ?, ?)", row)
        assert data == orig_data

        cursor.execute("SELECT extra, charstream, binarystream FROM test")
        rows = cursor.fetchall()
        data = [tuple(row) for row in data] * 2
        assert rows == data

    # When cache dropped on server, the scenario is different, due to cached query
    def test_streams_second(self, cursor, table_test_streams):
        data = [
            (133, "plain text", None),
            (134, None, b"binary data"),
            [135, "Caché", bytes("Caché", "utf-8")],
        ]
        cursor.executemany("INSERT INTO test (extra, charstream, binarystream) VALUES (?, ?, ?)", data)

        cursor.execute("SELECT extra, charstream, binarystream FROM test")
        rows = cursor.fetchall()
        data = [tuple(row) for row in data]
        assert rows == data

    def test_cursor_iter(self, cursor):
        cursor.execute("SELECT 1 UNION ALL SELECT 2")
        rows = []
        for row in cursor:
            rows.append(row[0])

        assert rows == [1, 2]

    def test_fetchmany(self, cursor):
        data = list(range(1, 8))
        cursor.execute("SELECT ? " + (("UNION ALL SELECT ? ") * (len(data) - 1)), data)
        assert cursor.fetchone() == (1,)
        assert cursor.fetchmany(2) == [(2,), (3,)]
        assert cursor.fetchmany(2) == [(4,), (5,)]
        assert cursor.fetchall() == [(6,), (7,)]

        assert cursor.fetchone() == None
        assert cursor.fetchmany() == []
        assert cursor.fetchall() == []

    def test_namedtuple(self, cursor):
        cursor.execute("SELECT 1 one, 2 two, 3 two, 4 one")
        for row in cursor.fetchall():
            assert row == (1, 2, 3, 4)
            assert row.one == 1
            assert getattr(row, "two") == 2

    def test_zero(self, cursor):
        cursor.execute("SELECT '01234' value")
        for row in cursor.fetchall():
            assert row == ("01234",)

        cursor.execute("SELECT * FROM (SELECT '01234' value) WHERE value = '01234'")
        for row in cursor.fetchall():
            assert row == ("01234",)

        cursor.execute(
            "SELECT * FROM (SELECT '01234' value) WHERE value = ?",
            [
                "01234",
            ],
        )
        for row in cursor.fetchall():
            assert row == ("01234",)

    @pytest.fixture
    def table_test_uuid(self, cursor):
        yield from self.create(
            cursor,
            "TABLE",
            "test_uuid",
            "(id UNIQUEIDENTIFIER PRIMARY KEY, val VARCHAR('10'))",
        )

    def test_uuid(self, cursor, table_test_uuid):
        data = [
            (uuid.uuid4(), "val1"),
            (uuid.uuid4(), "val2"),
            (uuid.uuid4(), "val3"),
        ]
        cursor.executemany("INSERT INTO test_uuid VALUES (?, ?)", data)

        cursor.execute("SELECT id, val from test_uuid")
        rows = cursor.fetchall()
        assert rows == data

        cursor.execute("SELECT id, val from test_uuid where id = ?", data[1][0])
        row = cursor.fetchone()
        assert row == data[1]

        cursor.execute("SELECT id, val from test_uuid where id = ?", str(data[1][0]))
        row = cursor.fetchone()
        assert row == data[1]
